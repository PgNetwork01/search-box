var searchBox = document.getElementById("searchbox");

var googleIcon = document.getElementById("Profileicon");

googleIcon.onclick = function(){ searchBox.classList.toggle("active");

}
